from django.urls import path
from . import views
from . views import PeliculasListView
from . views import PeliculasHomeListView

urlpatterns = [
    path('peliculas_index', views.peliculas_index, name="peliculas_index"),
    # path('', PeliculasListView.as_view(), name="welcome"),
    path('', views.home_show, name="welcome"),
    path('home', PeliculasHomeListView.as_view(), name="home"),

    # path('edit', views.edit, name="edit"),
    path('edit2', views.edit2, name="edit2"),
    # path('home', views.destroy, name="home"),
    # path('buscador', views.buscador, name="buscador"),
    
    # path('listar_peliculas', views.listar_peliculas, name="listar_peliculas"),
    # path('alta_pelicula', views.alta_pelicula, name="alta_pelicula"),


    path('generos/index', views.generos_index,name='generos_index'),
]
